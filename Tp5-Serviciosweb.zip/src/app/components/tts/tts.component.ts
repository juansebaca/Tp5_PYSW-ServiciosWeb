import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-tts',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card card-cyber p-4">
          <h2 class="text-neon-cyber mb-4 text-center">🎙️ TEXTO A VOZ (TTS)</h2>
          <div class="mb-3">
            <label class="form-label">Escribí el texto a procesar</label>
            <textarea class="form-control bg-dark text-light border-neon" rows="3" [(ngModel)]="texto"></textarea>
          </div>
          <div class="mb-4">
            <label class="form-label">Idioma / Voz</label>
            <select class="form-select bg-dark text-light border-neon" [(ngModel)]="idioma">
              <option value="es">Español (Castellano)</option>
              <option value="en">English (US)</option>
            </select>
          </div>
          <button class="btn btn-cyber-pink w-100 py-2 mb-4" (click)="generarAudio()">Generar Audio</button>
          
          <div *ngIf="audioUrl" class="text-center p-3 bg-black border-neon rounded">
            <p class="text-info small mb-2">▶️ Reproductor de Audio Retornado:</p>
            <audio controls [src]="audioUrl" class="w-100"></audio>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TtsComponent {
  texto: string = 'Hola, el sistema de síntesis de voz está listo y funcionando.';
  idioma: string = 'es';
  audioUrl: string | null = null;

  generarAudio() {
    this.audioUrl = `https://ttsmp3.com/created_mp3/876c5b0b2e8b2.mp3`; 
  }
}