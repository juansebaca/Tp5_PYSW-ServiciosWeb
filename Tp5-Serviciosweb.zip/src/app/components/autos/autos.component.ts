import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-autos',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container">
      <h2 class="text-neon-cyber mb-4 text-center">🚗 MARCAS DE CARROS DE LUJO</h2>
      <div class="row g-4">
        <div class="col-md-4" *ngFor="let marca of marcas">
          <div class="card card-cyber text-center p-4" style="cursor: pointer;" (click)="abrirModal(marca)">
            <h3 class="text-light fw-bold">{{ marca.nombre }}</h3>
            <span class="text-info">Ver modelos ➔</span>
          </div>
        </div>
      </div>

      <div class="modal fade show d-block" *ngIf="marcaSeleccionada" tabindex="-1" style="background: rgba(0,0,0,0.8);">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content card-cyber text-light">
            <div class="modal-header border-neon">
              <h5 class="modal-title text-neon-cyber">🤖 Modelos de {{ marcaSeleccionada.nombre }}</h5>
              <button type="button" class="btn-close btn-close-white" (click)="cerrarModal()"></button>
            </div>
            <div class="modal-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item bg-transparent text-light border-secondary" *ngFor="let modelo of marcaSeleccionada.modelos">
                  ⚡ {{ modelo }}
                </li>
              </ul>
            </div>
            <div class="modal-footer border-neon">
              <button type="button" class="btn btn-cyber-pink" (click)="cerrarModal()">Cerrar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AutosComponent {
  marcas = [
    { nombre: 'Lamborghini', modelos: ['Aventador SVJ', 'Huracán Evo', 'Urus Performante', 'Revuelto'] },
    { nombre: 'Ferrari', modelos: ['SF90 Stradale', 'LaFerrari', '812 Superfast', 'Purosangue'] },
    { nombre: 'BMW', modelos: ['M4 Competition', 'M5 CS', 'i8 Roadster', 'XM'] },
    { nombre: 'Mercedes-Benz', modelos: ['AMG GT Black Series', 'Clase G 63', 'EQS Sedan'] },
    { nombre: 'Porsche', modelos: ['911 GT3 RS', 'Taycan Turbo S', 'Cayenne Coupe'] },
    { nombre: 'Aston Martin', modelos: ['Vantage V8', 'DBS Superleggera', 'DBX707'] }
  ];

  marcaSeleccionada: any = null;

  abrirModal(marca: any) {
    this.marcaSeleccionada = marca;
  }

  cerrarModal() {
    this.marcaSeleccionada = null;
  }
}