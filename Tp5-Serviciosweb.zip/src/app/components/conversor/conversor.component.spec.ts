import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Conversor } from './conversor.component';

describe('Conversor', () => {
  let component: Conversor;
  let fixture: ComponentFixture<Conversor>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Conversor],
    }).compileComponents();

    fixture = TestBed.createComponent(Conversor);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
